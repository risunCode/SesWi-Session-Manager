(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))o(a);new MutationObserver(a=>{for(const n of a)if(n.type==="childList")for(const i of n.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&o(i)}).observe(document,{childList:!0,subtree:!0});function s(a){const n={};return a.integrity&&(n.integrity=a.integrity),a.referrerPolicy&&(n.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?n.credentials="include":a.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function o(a){if(a.ep)return;a.ep=!0;const n=s(a);fetch(a.href,n)}})();const fe="modulepreload",he=function(e){return"/"+e},ae={},I=function(t,s,o){let a=Promise.resolve();if(s&&s.length>0){let d=function(r){return Promise.all(r.map(u=>Promise.resolve(u).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};var i=d;document.getElementsByTagName("link");const l=document.querySelector("meta[property=csp-nonce]"),c=l?.nonce||l?.getAttribute("nonce");a=d(s.map(r=>{if(r=he(r),r in ae)return;ae[r]=!0;const u=r.endsWith(".css"),f=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${r}"]${f}`))return;const h=document.createElement("link");if(h.rel=u?"stylesheet":fe,u||(h.as="script"),h.crossOrigin="",h.href=r,c&&h.setAttribute("nonce",c),document.head.appendChild(h),u)return new Promise((C,S)=>{h.addEventListener("load",C),h.addEventListener("error",()=>S(new Error(`Unable to preload CSS for ${r}`)))})}))}function n(l){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=l,window.dispatchEvent(c),!c.defaultPrevented)throw l}return a.then(l=>{for(const c of l||[])c.status==="rejected"&&n(c.reason);return t().catch(n)})},p={success:(e,t)=>({success:!0,data:e,...t&&{message:t}}),error:(e,t)=>({success:!1,error:e?.message||String(e),...t&&{context:t}})},_={getBase(e){if(!e)throw new Error("Invalid URL");let t=e;try{e.includes("://")&&(t=new URL(e).hostname)}catch{t=e}if(t=t.replace(/^\[/,"").replace(/\]$/,""),/^(\d{1,3}\.){3}\d{1,3}$/.test(t)||t==="localhost")return t;const s=t.split(".").filter(Boolean);if(s.length<=2)return t;const o=new Set(["co.uk","ac.uk","gov.uk","com.au","net.au","co.id"]),a=`${s[s.length-2]}.${s[s.length-1]}`;return o.has(a)&&s.length>=3?`${s[s.length-3]}.${a}`:a},isMatch(e,t){if(!e||!t)return!1;const s=n=>n.replace(/^\./,"").toLowerCase(),o=s(e),a=s(t);return a===o||a.endsWith(`.${o}`)},isSensitive(e){if(!e)return!1;const t=e.toLowerCase();let s=t;try{s=_.getBase(t)}catch{}const o=new Set(["google.com","gmail.com","googleapis.com","gstatic.com","googleusercontent.com","google.co.id","google.co.uk","google.co.jp","google.co.in","youtube.com","youtube-nocookie.com","youtu.be","ytimg.com"]),a=new Set(["microsoft.com","outlook.com","office.com","live.com","microsoftonline.com","sharepoint.com","azure.com","msn.com"]);return o.has(s)||a.has(s)?!0:/google|gmail|googleapis|gstatic|googleusercontent|youtube|microsoft|office|outlook|live|msn|sharepoint|azure/i.test(t)}},m={escapeHtml(e){const t=document.createElement("div");return t.textContent=e==null?"":String(e),t.innerHTML},downloadFile(e,t,s){const o=new Blob([e],{type:s}),a=URL.createObjectURL(o),n=document.createElement("a");n.href=a,n.download=t,n.click(),URL.revokeObjectURL(a)},closeModal(e){if(!e)return;const t=e.querySelector(".modal-content");t?(t.classList.add("closing"),t.addEventListener("animationend",()=>{e.style.display="none",t.classList.remove("closing")},{once:!0})):e.style.display="none"},debounceInput(e,t,s=300){if(!e)return;let o;e.oninput=a=>{clearTimeout(o),o=setTimeout(()=>t(a.target.value),s)}}},B={formatRelative(e){const t=Date.now()-e,s=Math.floor(t/6e4),o=Math.floor(t/36e5),a=Math.floor(t/864e5),n=new Date(e),i=String(n.getDate()).padStart(2,"0"),l=String(n.getMonth()+1).padStart(2,"0"),c=String(n.getFullYear()).slice(2),d=String(n.getHours()).padStart(2,"0"),r=String(n.getMinutes()).padStart(2,"0"),u=`${i}/${l}/${c} ${d}:${r}`;return s<1?`${u} · just now`:s<60?`${u} · ${s}m ago`:o<24?`${u} · ${o}h ago`:`${u} · ${a}d ago`},getDaysLeft(e){if(!e)return 0;const t=new Date,s=new Date(e*1e3);return Math.ceil((s-t)/(1e3*60*60*24))},getSessionExpiration(e){if(!e?.length)return null;const t=Date.now()/1e3,s=e.filter(n=>n.expirationDate&&!n.session);if(!s.length)return e.some(i=>i.session||!i.expirationDate)?{status:"session",label:"Session",days:null,icon:"fa-clock"}:null;const o=Math.max(...s.map(n=>n.expirationDate)),a=Math.ceil((o-t)/86400);return a<=0?{status:"expired",label:"Expired",days:a,icon:"fa-circle-exclamation"}:a<=3?{status:"critical",label:`${a}d`,days:a,icon:"fa-triangle-exclamation"}:a<=7?{status:"warning",label:`${a}d`,days:a,icon:"fa-clock"}:a<=30?{status:"notice",label:`${a}d`,days:a,icon:"fa-clock"}:{status:"valid",label:`${a}d`,days:a,icon:"fa-circle-check"}}},F={get enabled(){try{return localStorage.getItem("__SES_DEBUG__")==="1"||window.__SES_DEBUG__===!0}catch{return!1}},log:(...e)=>F.enabled&&console.log("[SesWi]",...e),warn:(...e)=>F.enabled&&console.warn("[SesWi]",...e),error:(...e)=>console.error("[SesWi]",...e)},K={getPage(e,t,s=5){const o=(t-1)*s;return e.slice(o,o+s)},getTotalPages(e,t=5){return Math.ceil(e.length/t)}},oe={session(e){const s=["name","domain","cookies","timestamp"].filter(o=>!e?.[o]);return s.length?{valid:!1,error:`Missing: ${s.join(", ")}`}:Array.isArray(e.cookies)?{valid:!0}:{valid:!1,error:"Cookies must be array"}}},z={importSessions(e,t={}){return Array.isArray(e)?e.length>0&&e[0].name!==void 0&&e[0].timestamp===void 0?[this._wrapCookies(e,t)]:e:e&&Array.isArray(e.sessions)?e.sessions:e&&typeof e=="object"&&e.name&&e.domain?[e]:e&&Array.isArray(e.cookies)?[this._wrapCookies(e.cookies,{...t,localStorage:e.localStorage,sessionStorage:e.sessionStorage})]:[]},_wrapCookies(e,t={}){const s={};e.forEach(a=>{const n=(a.domain||"").replace(/^\./,"");s[n]=(s[n]||0)+1});const o=Object.entries(s).sort((a,n)=>n[1]-a[1])[0]?.[0]||"unknown";return{name:t.name||`Imported ${new Date().toLocaleDateString()}`,domain:t.domain||o,originalUrl:t.originalUrl||`https://${t.domain||o}`,cookies:e,localStorage:t.localStorage||{},sessionStorage:t.sessionStorage||{},timestamp:t.timestamp||Date.now(),index:t.index||1}}},ne=100;function ie(e,t){const s=[];for(let o=0;o<e.length;o+=t)s.push(e.slice(o,o+t));return s}function le(e){const t=e.domain.startsWith(".")?e.domain.slice(1):e.domain;return`http${e.secure?"s":""}://${t}${e.path}`}function ye(e){const t={...e};return e.hostOnly&&delete t.domain,e.session&&delete t.expirationDate,delete t.hostOnly,delete t.session,t}const R={async getForDomain(e){try{const s=(await chrome.cookies.getAll({})).filter(o=>{const a=o.domain.startsWith(".")?o.domain.slice(1):o.domain;return _.isMatch(e,a)});return p.success(s)}catch(t){return p.error(t,"Cookies.getForDomain")}},async getCurrentTab(){try{const[e]=await chrome.tabs.query({active:!0,currentWindow:!0}),t=_.getBase(e.url),{data:s}=await this.getForDomain(t);return p.success({cookies:s,domain:t,url:e.url})}catch(e){return p.error(e,"Cookies.getCurrentTab")}},async removeForDomain(e){try{const{data:t}=await this.getForDomain(e);let s=0;for(const o of ie(t,ne))await Promise.all(o.map(async a=>{try{await chrome.cookies.remove({url:le(a),name:a.name,storeId:a.storeId}),s++}catch{}}));return p.success(s)}catch(t){return p.error(t,"Cookies.removeForDomain")}},async restore(e){try{if(!e.cookies?.length)return p.error("No cookies to restore");await this.removeForDomain(e.domain);let t=0;for(const s of ie(e.cookies,ne))await Promise.all(s.map(async o=>{try{const a=ye(o);await chrome.cookies.set({url:le(o),...a}),t++}catch{}}));return p.success({restored:t,total:e.cookies.length})}catch(t){return p.error(t,"Cookies.restore")}}},ce=Object.freeze(Object.defineProperty({__proto__:null,Cookies:R},Symbol.toStringTag,{value:"Module"})),ee="_seswi_meta",ve="seswi-sessions-blyat";let j=null;async function H(){if(j)return j;try{const e=await chrome.storage.local.get(ee);if(e[ee]?.storageKey)return j=e[ee].storageKey,j}catch{}return j=ve,j}let U=null,G=0;const O={async getCurrent(){if(U&&Date.now()-G<400)return U;try{const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.url)return p.error("No active tab");if(e.url.startsWith("chrome://")||e.url.startsWith("chrome-extension://")){const o=p.success({domain:"chrome://",url:e.url,tabId:e.id});return U=o,G=Date.now(),o}const t=_.getBase(e.url),s=p.success({domain:t,url:e.url,tabId:e.id});return U=s,G=Date.now(),s}catch(e){return p.error(e,"TabInfo.getCurrent")}},async cleanCurrentTab(e={}){const{cookies:t=!0,localStorage:s=!0,sessionStorage:o=!0,history:a=!0,cache:n=!1}=e;try{const i=await this.getCurrent();if(!i.success)throw new Error("Failed to get tab info");const{tabId:l,url:c}=i.data,d=_.getBase(c);if(t&&await R.removeForDomain(d),a)try{if(chrome.history?.search&&chrome.history?.deleteUrl){const u=(await chrome.history.search({text:d,maxResults:1e3,startTime:0})).filter(f=>{try{const h=new URL(f.url).hostname;return _.isMatch(d,h)}catch{return!1}});for(let f=0;f<u.length;f+=50){const h=u.slice(f,f+50);await Promise.all(h.map(C=>chrome.history.deleteUrl({url:C.url}).catch(()=>{})))}}}catch(r){F.error("Error clearing history:",r)}if(n)try{try{await chrome.browsingData.removeCache({origins:[`https://${d}`,`http://${d}`]})}catch{await chrome.browsingData.removeCache({})}}catch(r){F.error("Error clearing cache:",r)}return(s||o)&&await chrome.scripting.executeScript({target:{tabId:l},func:(r,u)=>{if(r)try{localStorage.clear()}catch{}if(u)try{sessionStorage.clear()}catch{}},args:[s,o]}),await chrome.tabs.reload(l),U=null,G=0,p.success(null,"Tab data cleared")}catch(i){return p.error(i,"TabInfo.cleanCurrentTab")}}},b={async getAll(){try{const e=await H(),s=((await chrome.storage.local.get(e))[e]||[]).filter(o=>oe.session(o).valid);return p.success(s)}catch(e){return p.error(e,"SessionStorage.getAll")}},async save(e){try{const t=oe.session(e);if(!t.valid)return p.error(t.error);const{data:s}=await this.getAll();if(s.some(n=>n.domain===e.domain&&n.name.toLowerCase()===e.name.toLowerCase()))return p.error("Duplicate session name");const a=await H();return await chrome.storage.local.set({[a]:[...s,e]}),p.success(e)}catch(t){return p.error(t,"SessionStorage.save")}},async update(e){try{const{data:t}=await this.getAll(),s=t.map(a=>a.timestamp===e.timestamp?e:a),o=await H();return await chrome.storage.local.set({[o]:s}),p.success(e)}catch(t){return p.error(t,"SessionStorage.update")}},async delete(e){try{const{data:t}=await this.getAll(),s=await H();return await chrome.storage.local.set({[s]:t.filter(o=>o.timestamp!==e)}),p.success(null)}catch(t){return p.error(t,"SessionStorage.delete")}},async getByDomain(e){try{const{data:t}=await this.getAll(),s=t.filter(o=>_.isMatch(o.domain,e)).sort((o,a)=>a.timestamp-o.timestamp);return p.success(s)}catch(t){return p.error(t,"SessionStorage.getByDomain")}},async getGroupedByDomain(){try{const{data:e}=await this.getAll(),t={};e.forEach(o=>{t[o.domain]||(t[o.domain]=[]),t[o.domain].push(o)});const s=Object.keys(t).sort((o,a)=>{const n=Math.max(...t[o].map(l=>l.timestamp));return Math.max(...t[a].map(l=>l.timestamp))-n}).map(o=>({domain:o,sessions:t[o].sort((a,n)=>(a.index||0)-(n.index||0))}));return p.success(s)}catch(e){return p.error(e,"SessionStorage.getGroupedByDomain")}},async deleteGrouped(e){try{const{data:t}=await this.getAll(),s=t.filter(a=>!e.includes(a.domain)),o=await H();return await chrome.storage.local.set({[o]:s}),p.success({deleted:t.length-s.length})}catch(t){return p.error(t,"SessionStorage.deleteGrouped")}},async deleteMany(e){try{const t=new Set(e),{data:s}=await this.getAll(),o=s.filter(n=>!t.has(n.timestamp)),a=await H();return await chrome.storage.local.set({[a]:o}),p.success({deleted:s.length-o.length})}catch(t){return p.error(t,"SessionStorage.deleteMany")}}},N={async get(e,t="local"){try{const s=await chrome.scripting.executeScript({target:{tabId:e},func:o=>{const a=o==="session"?sessionStorage:localStorage,n={};for(let i=0;i<a.length;i++){const l=a.key(i);l&&(n[l]=a.getItem(l))}return n},args:[t]});return p.success(s?.[0]?.result||{})}catch(s){return p.error(s,`BrowserStorage.get(${t})`)}},async restore(e,t={},s={}){try{return await chrome.scripting.executeScript({target:{tabId:e},func:(o,a)=>{if(o&&Object.keys(o).length>0){try{localStorage.clear()}catch{}for(const[n,i]of Object.entries(o))try{localStorage.setItem(n,i)}catch{}}if(a&&Object.keys(a).length>0){try{sessionStorage.clear()}catch{}for(const[n,i]of Object.entries(a))try{sessionStorage.setItem(n,i)}catch{}}},args:[t,s]}),p.success({localStorage:Object.keys(t).length,sessionStorage:Object.keys(s).length})}catch(o){return p.error(o,"BrowserStorage.restore")}},async getLocal(e){return this.get(e,"local")},async getSession(e){return this.get(e,"session")}},te=Object.freeze(Object.defineProperty({__proto__:null,BrowserStorage:N,SessionStorage:b,TabInfo:O},Symbol.toStringTag,{value:"Module"}));class be{constructor(){this.domainToIcon={},this.lastFetchedAt=0,this.cacheMs=6e4,this.entryTtlMs=1440*60*1e3,this.maxEntries=300,this._fetchInFlight=null,this._listenersInitialized=!1,this._saveTimer=null,this._storageKey="tabIconsCacheV1",this._loadCache(),this._initListeners()}async _loadCache(){try{const s=(await chrome.storage.local.get(this._storageKey))[this._storageKey];s&&typeof s=="object"&&(this.domainToIcon=s,this._prune())}catch{}}_scheduleSave(){clearTimeout(this._saveTimer),this._saveTimer=setTimeout(async()=>{try{await chrome.storage.local.set({[this._storageKey]:this.domainToIcon})}catch{}},300)}_initListeners(){if(!this._listenersInitialized){this._listenersInitialized=!0;try{chrome.tabs.onUpdated.addListener((t,s,o)=>{if(s.favIconUrl||s.url){const a=o?.url?(()=>{try{return _.getBase(o.url)}catch{return null}})():null;a&&o.favIconUrl&&this._set(a,o.favIconUrl)}}),chrome.tabs.onRemoved.addListener(()=>{this.lastFetchedAt=0}),chrome.tabs.onCreated.addListener(()=>{this.lastFetchedAt=0})}catch{}}}_set(t,s){const o=this.domainToIcon[t],a=Date.now();!o||o.url!==s?(this.domainToIcon[t]={url:s,ts:a},this._prune(),this._scheduleSave()):o.ts=a}_prune(){const t=Date.now();for(const[o,a]of Object.entries(this.domainToIcon))(!a?.url||t-(a.ts||0)>this.entryTtlMs)&&delete this.domainToIcon[o];const s=Object.entries(this.domainToIcon);s.length>this.maxEntries&&s.sort((o,a)=>(o[1].ts||0)-(a[1].ts||0)).slice(0,s.length-this.maxEntries).forEach(([o])=>delete this.domainToIcon[o])}_asPlainMap(){const t={};for(const[s,o]of Object.entries(this.domainToIcon))o?.url&&(t[s]=o.url);return t}getCached(){return this._prune(),this._asPlainMap()}async _queryAllTabs(){try{const t=await chrome.tabs.query({});for(const s of t){if(!s.url)continue;let o=null;try{o=_.getBase(s.url)}catch{}const a=s.favIconUrl||"";o&&a&&this._set(o,a)}return this.lastFetchedAt=Date.now(),this._asPlainMap()}catch{return this._asPlainMap()}}async refresh(){return this._prune(),Date.now()-this.lastFetchedAt<this.cacheMs&&Object.keys(this.domainToIcon).length?this._asPlainMap():(this._fetchInFlight||(this._fetchInFlight=this._queryAllTabs().finally(()=>{this._fetchInFlight=null})),this._fetchInFlight)}async getDomainIcon(t){return this._prune(),this.domainToIcon[t]?.url?this.domainToIcon[t].url:(await this.refresh(),this.domainToIcon[t]?.url||null)}getFaviconUrl(t,s){const o=this.domainToIcon[t]?.url;if(o)return o;const a=s||`https://${t}`;return`chrome-extension://${chrome.runtime.id}/_favicon/?pageUrl=${encodeURIComponent(a)}&size=32`}}const Y=new be,Se={toJSON(e){return JSON.stringify(e,null,2)},toNetscape(e){const t=["# Netscape HTTP Cookie File","# This was generated by SesWi (https://github.com/risunCode/SesWi-Session-Manager)","# Do not edit.",""].join(`
`),s=e.sort((o,a)=>{const n=o.domain||"",i=a.domain||"";return n.localeCompare(i)}).map(o=>{const a=o.domain.startsWith(".")?o.domain:`.${o.domain}`,n="TRUE",i=o.path||"/",l=o.secure?"TRUE":"FALSE";let c=0;return o.expirationDate?c=Math.round(o.expirationDate):c=0,[a,n,i,l,c,o.name,o.value].join("	")});return t+`
`+s.join(`
`)}},re=()=>window.sjcl,J={encrypt(e,t){const s=re();if(!s)throw new Error("SJCL not loaded");const o=JSON.stringify(e);return s.encrypt(t,o,{mode:"ccm",ts:128,ks:256,iter:1e3})},decrypt(e,t){const s=re();if(!s)throw new Error("SJCL not loaded");const o=s.decrypt(t,e);return JSON.parse(o)},async exportOWI(e,t,s="sessions-backup"){try{if(!t?.trim())return p.error("Password required");const o={version:"1.0",exportDate:new Date().toISOString(),sessions:e},a=this.encrypt(o,t),n={version:"1.0",format:"OWI",created:new Date().toISOString(),type:"multi",encryptedData:a};return m.downloadFile(JSON.stringify(n,null,2),`${s}.owi`,"application/octet-stream"),p.success(null,"OWI created")}catch(o){return F.error("exportOWI failed:",o),p.error(o,"Crypto.exportOWI")}},async importOWI(e,t){try{const s=JSON.parse(e);if(s.format!=="OWI"||!s.encryptedData)return p.error("Invalid OWI file");const o=this.decrypt(s.encryptedData,t),a=z.importSessions(o);return a.length?p.success({sessions:a}):p.error("No sessions found in OWI file")}catch(s){return F.error("importOWI failed:",s),p.error(s,"Crypto.importOWI")}}},we=Object.freeze(Object.defineProperty({__proto__:null,Crypto:J},Symbol.toStringTag,{value:"Module"}));let E={session:null};function xe(e){return e?e.status==="expired"?`Expired ${Math.abs(e.days)}d ago`:e.status==="critical"?`Critical: ${e.days}d`:e.status==="warning"||e.status==="notice"?`Warning: ${e.days}d`:e.status==="valid"?`Valid: ${e.days}d`:e.status==="session"?"Session only":"No cookies":"No cookies"}function Ce(e){if(!e?.length)return"";const t=e.filter(a=>!a.session&&a.expirationDate).sort((a,n)=>n.expirationDate-a.expirationDate),s=e.filter(a=>a.session||!a.expirationDate);if(!t.length&&!s.length)return"";const o=t.slice(0,4).map(a=>{const n=B.getDaysLeft(a.expirationDate),i=new Date(a.expirationDate*1e3).toLocaleDateString("en-GB"),l=n<=0?"Expired":i,c=n<=0?`${Math.abs(n)}d ago`:`${n}d left`,d=a.name.length>18?a.name.slice(0,15)+"...":a.name;return`
      <div class="exp-pill ${n<=0?"expired":n<=7?"warning":"valid"}">
        <div class="exp-pill-left"><span class="exp-pill-dot"></span><span class="exp-pill-name">${m.escapeHtml(d)}</span></div>
        <div class="exp-pill-right"><span class="exp-pill-date">${l}</span><span class="exp-pill-days">${c}</span></div>
      </div>`}).join("");return`
    <div class="exp-details" id="authDetails">
      <div class="exp-details-meta">
        <span><i class="fa-solid fa-circle-check" style="color:#10b981;"></i> ${t.length} expiring</span>
        <span><i class="fa-solid fa-clock" style="color:#6366f1;"></i> ${s.length} session-only</span>
      </div>
      <div class="exp-pills-list">${o}</div>
      ${t.length>4?`<div class="exp-pills-more">+${t.length-4} more cookies</div>`:""}
    </div>`}function ke(e){const t=e.cookies?.length||0,s=Object.keys(e.localStorage||{}).length,o=Object.keys(e.sessionStorage||{}).length,a=B.getSessionExpiration(e.cookies||[]),n=a?.status||"neutral",i=a?.icon?`fa-solid ${a.icon}`:"fa-solid fa-circle-check",l=xe(a);return`
    <div class="sa-info-card">
      <div class="sa-info-card-top" id="savedDataCard">
        <div class="sa-info-stat">
          <i class="fa-solid fa-cookie" style="color:#d97706;"></i>
          <span>${t}</span><label>Cookies</label>
        </div>
        <div class="sa-info-sep"></div>
        <div class="sa-info-stat">
          <i class="fa-solid fa-database" style="color:#059669;"></i>
          <span>${s}</span><label>Local</label>
        </div>
        <div class="sa-info-sep"></div>
        <div class="sa-info-stat">
          <i class="fa-solid fa-hard-drive" style="color:#2563eb;"></i>
          <span>${o}</span><label>Session</label>
        </div>
        <div class="sa-info-sep"></div>
        <div class="sa-info-view"><i class="fa-solid fa-chevron-right"></i></div>
      </div>
      <div class="sa-info-card-bottom sa-exp-bar ${n}" id="authStatusCard">
        <i class="${i} sa-exp-icon"></i>
        <span class="sa-exp-text"><span class="sa-exp-status">${l}</span></span>
        <i class="fa-solid fa-chevron-down sa-exp-chevron"></i>
      </div>
    </div>
  `}function Ee(e,t){if(t==="cookies"){const s=e.cookies||[];return s.length===0?'<div class="empty-data-msg">No cookies saved</div>':s.map(o=>{const a=[o.secure?"Secure":"",o.httpOnly?"HttpOnly":"",o.sameSite?`SameSite:${o.sameSite}`:""].filter(Boolean).join(" · ")||"—",n=m.escapeHtml(o.name||""),i=o.value||"",l=m.escapeHtml(i.slice(0,50)+(i.length>50?"...":""));let c="Session",d="valid";if(!o.session&&o.expirationDate){const r=B.getDaysLeft(o.expirationDate),u=new Date(o.expirationDate*1e3).toLocaleDateString();c=r>0?`${u} (${r}d)`:"Expired",d=r<=0?"expired":r<=30?"warning":"valid"}return`
        <div class="data-row">
          <div class="data-row-header">
            <span class="data-row-name">${n}</span>
            <div class="data-row-actions">
              <span class="data-row-exp ${d}">${c}</span>
              <button class="data-copy-btn" data-copy="${m.escapeHtml(i)}" title="Copy value"><i class="fa-solid fa-copy"></i></button>
            </div>
          </div>
          <div class="data-row-flags">${a}</div>
          <div class="data-row-value">${l}</div>
        </div>
      `}).join("")}if(t==="localStorage"||t==="sessionStorage"){const s=e[t]||{},o=Object.entries(s);return o.length===0?`<div class="empty-data-msg">No ${t} saved</div>`:o.map(([a,n])=>{const i=typeof n=="string"?n:JSON.stringify(n),l=i.length>60?i.slice(0,57)+"...":i;return`
        <div class="data-row">
          <div class="data-row-header">
            <span class="data-row-name">${m.escapeHtml(a)}</span>
            <button class="data-copy-btn" data-copy="${m.escapeHtml(i)}" title="Copy value"><i class="fa-solid fa-copy"></i></button>
          </div>
          <div class="data-row-value">${m.escapeHtml(l)}</div>
        </div>
      `}).join("")}return""}function Me(e){E.session=e,_e();const t=document.getElementById("sessionActionsModal"),s=t.querySelector("#saHeader"),o=t.querySelector("#saExpContainer"),a=t.querySelector("#saMessage"),n=e.originalUrl||`https://${e.domain}`;if(s){const i=Y.getFaviconUrl(e.domain,e.originalUrl);s.innerHTML=`
      <div class="sa-header-card">
        <div class="sa-header-row1">
          <img class="sa-favicon" src="${m.escapeHtml(i)}" alt=""
            onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <span class="sa-favicon-fallback"><i class="fa-solid fa-globe"></i></span>
          <span class="sa-header-domain">${m.escapeHtml(e.domain)}</span>
          <button id="saVisitBtn" class="sa-visit-icon-btn" title="${m.escapeHtml(n)}">
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
          </button>
        </div>
        <div class="sa-header-row2">
          <span class="sa-header-name">${m.escapeHtml(e.name)}</span>
          <span class="sa-header-sep">·</span>
          <span class="sa-header-meta">#${e.index||1} · ${B.formatRelative(e.timestamp)}</span>
        </div>
      </div>
    `}if(o){o.innerHTML=ke(e)+Ce(e.cookies||[]);const i=t.querySelector("#savedDataCard");i&&(i.onclick=()=>Ie(e));const l=t.querySelector("#authStatusCard"),c=t.querySelector("#authDetails");l&&c&&(l.onclick=()=>{l.classList.toggle("expanded"),c.classList.toggle("show")})}a&&(a.textContent="",a.style.display="none"),qe(),t.style.display="block"}function Ie(e){Te();const t=document.getElementById("savedDataModal"),s=t.querySelector("#savedDataBody"),o=e.cookies?.length||0,a=Object.keys(e.localStorage||{}).length,n=Object.keys(e.sessionStorage||{}).length;t.querySelector("#sdTabCookies").innerHTML=`<i class="fa-solid fa-cookie mr-1"></i>Cookies <span class="tab-count">${o}</span>`,t.querySelector("#sdTabLocalStorage").innerHTML=`<i class="fa-solid fa-database mr-1"></i>localStorage <span class="tab-count">${a}</span>`,t.querySelector("#sdTabSessionStorage").innerHTML=`<i class="fa-solid fa-hard-drive mr-1"></i>sessionStorage <span class="tab-count">${n}</span>`;const i=l=>{t.querySelectorAll(".sd-tab-btn").forEach(c=>c.classList.remove("active")),t.querySelector(`#sdTab${l.charAt(0).toUpperCase()+l.slice(1)}`).classList.add("active"),s.innerHTML=Ee(e,l)};s.onclick=async l=>{const c=l.target.closest(".data-copy-btn");if(!c)return;const d=c.dataset.copy;await navigator.clipboard.writeText(d);const r=c.querySelector("i");r.className="fa-solid fa-check",c.classList.add("copied"),setTimeout(()=>{r.className="fa-solid fa-copy",c.classList.remove("copied")},1200)},i("cookies"),t.querySelector("#sdTabCookies").onclick=()=>i("cookies"),t.querySelector("#sdTabLocalStorage").onclick=()=>i("localStorage"),t.querySelector("#sdTabSessionStorage").onclick=()=>i("sessionStorage"),t.style.display="block"}function _e(){if(document.getElementById("sessionActionsModal"))return;document.body.insertAdjacentHTML("beforeend",`
    <div id="sessionActionsModal" class="modal">
      <div class="modal-content sa-modal">
        <div class="modal-header">
          <div class="traffic-lights">
            <span class="tl-btn tl-close" id="saTlClose"></span>
            <span class="tl-btn tl-minimize"></span>
            <span class="tl-btn tl-maximize"></span>
          </div>
          <h3><i class="fa-solid fa-gear mr-2 text-slate-500"></i>Session Actions</h3>
        </div>
        <div class="modal-body">
          <div id="saHeader" class="sa-header"></div>
          <div id="saExpContainer"></div>
          <div class="modal-message" id="saMessage"></div>

          <button class="sa-btn sa-btn-primary sa-btn-full" id="saRestore">
            <i class="fa-solid fa-rotate-left"></i><span>Restore Session</span>
          </button>

          <div class="sa-row">
            <button class="sa-btn sa-btn-secondary" id="saRename"><i class="fa-solid fa-pen"></i><span>Edit</span></button>
            <button class="sa-btn sa-btn-secondary" id="saReplace"><i class="fa-solid fa-arrows-rotate"></i><span>Replace</span></button>
          </div>

          <div class="sa-row">
            <button class="sa-btn sa-btn-export" id="saExportJSON"><i class="fa-solid fa-file-code"></i><span>Export JSON</span></button>
            <button class="sa-btn sa-btn-export" id="saExportOWI"><i class="fa-solid fa-lock"></i><span>Export OWI</span></button>
          </div>

          <button class="sa-btn sa-btn-danger-outline sa-btn-full" id="saDelete">
            <i class="fa-solid fa-trash"></i><span>Delete Session</span>
          </button>
        </div>
      </div>
    </div>
  `);const t=document.getElementById("sessionActionsModal"),s=()=>m.closeModal(t);t.onclick=o=>{o.target===t&&s()},t.querySelector("#saTlClose").onclick=s}function Te(){if(document.getElementById("savedDataModal"))return;document.body.insertAdjacentHTML("beforeend",`
    <div id="savedDataModal" class="modal">
      <div class="modal-content saved-data-modal">
        <div class="modal-header">
          <div class="traffic-lights">
            <span class="tl-btn tl-close" id="sdTlClose"></span>
            <span class="tl-btn tl-minimize"></span>
            <span class="tl-btn tl-maximize"></span>
          </div>
          <h3><i class="fa-solid fa-database mr-2 text-emerald-500"></i>Saved Data</h3>
        </div>
        <div class="sd-tabs">
          <button class="sd-tab-btn active" id="sdTabCookies"><i class="fa-solid fa-cookie mr-1"></i>Cookies <span class="tab-count">0</span></button>
          <button class="sd-tab-btn" id="sdTabLocalStorage"><i class="fa-solid fa-database mr-1"></i>localStorage <span class="tab-count">0</span></button>
          <button class="sd-tab-btn" id="sdTabSessionStorage"><i class="fa-solid fa-hard-drive mr-1"></i>sessionStorage <span class="tab-count">0</span></button>
        </div>
        <div class="modal-body">
          <div id="savedDataBody" class="saved-data-list"></div>
        </div>
      </div>
    </div>
  `);const t=document.getElementById("savedDataModal"),s=()=>m.closeModal(t);t.onclick=o=>{o.target===t&&s()},t.querySelector("#sdTlClose").onclick=s}function qe(){const e=document.getElementById("sessionActionsModal"),t=e.querySelector("#saMessage"),s=(a,n)=>{t.textContent=a,t.className=`modal-message ${n||""}`,t.style.display=a?"block":"none"},o=async()=>{const a=E.session;if(!a)return{allowed:!1,tabInfo:null};const n=await O.getCurrent();return{allowed:n.success&&_.isMatch(a.domain,n.data.domain),tabInfo:n}};e.querySelector("#saVisitBtn").onclick=async()=>{const a=E.session;if(!a)return;const n=a.originalUrl||`https://${a.domain}`;chrome?.tabs?.create?await chrome.tabs.create({url:n}):window.open(n,"_blank")},e.querySelector("#saRestore").onclick=async()=>{const a=E.session;if(!a)return;const{allowed:n,tabInfo:i}=await o();if(!n){s(`Open ${a.domain} first`,"error");return}const l=a.cookies?.length>0,c=Object.keys(a.localStorage||{}).length>0,d=Object.keys(a.sessionStorage||{}).length>0;if(!l&&!c&&!d){s("Nothing to restore","error");return}s("Restoring...","");const r=i.data.tabId;l&&await R.restore(a),r&&(c||d)&&await N.restore(r,a.localStorage||{},a.sessionStorage||{}),s("Restored!","success"),r&&(await chrome.tabs.reload(r),setTimeout(()=>m.closeModal(e),500))},e.querySelector("#saRename").onclick=async()=>{if(!E.session)return;const{Modal:a}=await I(async()=>{const{Modal:n}=await Promise.resolve().then(()=>Q);return{Modal:n}},void 0);a.openEditSession(E.session,()=>{s("Updated!","success"),setTimeout(()=>m.closeModal(e),500)})},e.querySelector("#saReplace").onclick=async()=>{const a=E.session;if(!a)return;const{allowed:n}=await o();if(!n){s(`Open ${a.domain} first`,"error");return}const{Modal:i}=await I(async()=>{const{Modal:l}=await Promise.resolve().then(()=>Q);return{Modal:l}},void 0);i.openReplaceConfirm(a,()=>{setTimeout(()=>m.closeModal(e),300)})},e.querySelector("#saDelete").onclick=async()=>{if(!E.session)return;const{Modal:a}=await I(async()=>{const{Modal:n}=await Promise.resolve().then(()=>Q);return{Modal:n}},void 0);a.openDeleteConfirm(E.session,()=>{setTimeout(()=>m.closeModal(e),300)})},e.querySelector("#saExportJSON").onclick=()=>{const a=E.session;if(!a)return;const n={cookies:a.cookies,localStorage:a.localStorage,sessionStorage:a.sessionStorage};m.downloadFile(JSON.stringify(n,null,2),`${a.domain}-${a.name}.json`,"application/json"),s("JSON exported!","success")},e.querySelector("#saExportOWI").onclick=async()=>{if(!E.session)return;const{Modal:a}=await I(async()=>{const{Modal:n}=await Promise.resolve().then(()=>Q);return{Modal:n}},void 0);a.openOWIExport(E.session,()=>{s("OWI exported!","success")})}}const M={openSessionActions:Me,openBackupFormat(){this._ensureBackupModal();const e=document.getElementById("backupFormatModal"),t=e.querySelector("#bfMessage");t.textContent="",t.className="modal-message",e.querySelector("#bfPassword").value="",e.querySelector("#bfPwdWrap").classList.add("hidden"),e.querySelector("#bfJSON").classList.remove("selected"),e.querySelector("#bfOWI").classList.remove("selected"),e._format="json",e.style.display="block"},_ensureBackupModal(){if(document.getElementById("backupFormatModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="backupFormatModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="bfTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-folder-open mr-2 text-blue-500"></i>Backup Format</h3>
          </div>
          <div class="modal-body">
            <div class="modal-options">
              <button class="option-card" id="bfJSON">
                <i class="fa-solid fa-file-code text-2xl text-amber-500"></i>
                <span class="option-title">JSON</span>
                <span class="option-desc">Unencrypted</span>
              </button>
              <button class="option-card" id="bfOWI">
                <i class="fa-solid fa-lock text-2xl text-violet-500"></i>
                <span class="option-title">OWI</span>
                <span class="option-desc">Encrypted</span>
              </button>
            </div>
            <div id="bfPwdWrap" class="hidden">
              <input type="password" id="bfPassword" placeholder="Enter password for encryption" />
            </div>
            <div class="modal-message" id="bfMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="bfCancel">Cancel</button>
            <button class="btn btn-primary" id="bfCreate"><i class="fa-solid fa-download mr-1"></i>Create Backup</button>
          </div>
        </div>
      </div>
    `),this._wireBackupModal()},_wireBackupModal(){const e=document.getElementById("backupFormatModal"),t=e.querySelector("#bfPwdWrap"),s=e.querySelector("#bfPassword"),o=e.querySelector("#bfMessage"),a=()=>m.closeModal(e);e.onclick=n=>{n.target===e&&a()},e.querySelector("#bfTlClose").onclick=a,e.querySelector("#bfCancel").onclick=a,e.querySelector("#bfJSON").onclick=()=>{e._format="json",t.classList.add("hidden"),e.querySelector("#bfJSON").classList.add("selected"),e.querySelector("#bfOWI").classList.remove("selected")},e.querySelector("#bfOWI").onclick=()=>{e._format="owi",t.classList.remove("hidden"),e.querySelector("#bfOWI").classList.add("selected"),e.querySelector("#bfJSON").classList.remove("selected")},e.querySelector("#bfCreate").onclick=async()=>{const n=e._format||"json",{data:i}=await b.getAll();if(n==="json")m.downloadFile(JSON.stringify(i,null,2),"sessions-backup.json","application/json"),m.closeModal(e);else{const l=s.value.trim();if(!l){o.textContent="Password required",o.className="modal-message error";return}const c=await J.exportOWI(i,l);c.success?m.closeModal(e):(o.textContent=c.error,o.className="modal-message error")}}},openRestore(){this._ensureRestoreModal();const e=document.getElementById("restoreModal");e.querySelector("#rmDrop").querySelector("span").innerHTML='<i class="fa-solid fa-folder-open mr-1"></i>Drop .json or .owi file(s)',e.querySelector("#rmMessage").textContent="",e.querySelector("#rmPwdWrap").classList.add("hidden"),e.querySelector("#rmFile").value="",e.querySelector("#rmFileList").innerHTML="",e._parsedSessions=[],e._fileType=null,e.style.display="block"},_ensureRestoreModal(){if(document.getElementById("restoreModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="restoreModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="rmTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-upload mr-2 text-emerald-500"></i>Restore Backup</h3>
          </div>
          <div class="modal-body">
            <div class="dropzone" id="rmDrop">
              <span><i class="fa-solid fa-folder-open mr-1"></i>Drop .json or .owi file(s)</span>
            </div>
            <input type="file" id="rmFile" accept=".json,.owi" class="hidden" multiple />
            <div id="rmFileList" class="rm-file-list"></div>
            <div id="rmPwdWrap" class="hidden flex gap-2 mt-3">
              <input type="password" id="rmPassword" placeholder="Password for OWI" class="flex-1" />
              <button id="rmVerify" class="btn btn-primary px-4"><i class="fa-solid fa-check mr-1"></i>Verify</button>
            </div>
            <div class="modal-message" id="rmMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="rmCancel">Cancel</button>
            <button class="btn btn-primary" id="rmRestore"><i class="fa-solid fa-upload mr-1"></i>Restore</button>
          </div>
        </div>
      </div>
    `),this._wireRestoreModal()},_wireRestoreModal(){const e=document.getElementById("restoreModal"),t=e.querySelector("#rmDrop"),s=e.querySelector("#rmFile"),o=e.querySelector("#rmFileList"),a=e.querySelector("#rmPwdWrap"),n=e.querySelector("#rmMessage"),i=()=>m.closeModal(e);e.onclick=l=>{l.target===e&&i()},e.querySelector("#rmTlClose").onclick=i,e.querySelector("#rmCancel").onclick=i,t.onclick=()=>s.click(),t.ondragover=l=>{l.preventDefault(),t.classList.add("dragover")},t.ondragleave=()=>t.classList.remove("dragover"),t.ondrop=l=>{l.preventDefault(),t.classList.remove("dragover"),l.dataTransfer.files?.length&&(s.files=l.dataTransfer.files,s.dispatchEvent(new Event("change")))},s.onchange=async()=>{const l=Array.from(s.files||[]);if(!l.length)return;e._parsedSessions=[],e._fileType=null,o.innerHTML="",n.textContent="",n.className="modal-message";const c=l.filter(r=>r.name.toLowerCase().endsWith(".owi")),d=l.filter(r=>r.name.toLowerCase().endsWith(".json"));if(c.length>0){const r=c[0];e._fileType="owi",e._owiFile=r,a.classList.remove("hidden"),t.querySelector("span").innerHTML=`<i class="fa-solid fa-lock mr-1"></i>${m.escapeHtml(r.name)}`,n.textContent="Enter password to verify OWI file",n.className="modal-message"}else if(d.length>0){e._fileType="json",a.classList.add("hidden"),t.querySelector("span").innerHTML=`<i class="fa-solid fa-file-code mr-1"></i>${d.length} file(s) selected`;let r=0;const u=[];for(const f of d)try{const h=await f.text(),C=JSON.parse(h),S=z.importSessions(C);e._parsedSessions.push(...S),r+=S.length,o.insertAdjacentHTML("beforeend",`<div class="rm-file-item success"><i class="fa-solid fa-check"></i>${m.escapeHtml(f.name)} <span>(${S.length})</span></div>`)}catch{u.push(f.name),o.insertAdjacentHTML("beforeend",`<div class="rm-file-item error"><i class="fa-solid fa-xmark"></i>${m.escapeHtml(f.name)} <span>Invalid</span></div>`)}r>0?(n.textContent=`Found ${r} sessions from ${d.length-u.length} file(s)`,n.className="modal-message success"):(n.textContent="No valid sessions found",n.className="modal-message error")}},e.querySelector("#rmVerify").onclick=async()=>{const l=e._owiFile||s.files?.[0],c=e.querySelector("#rmPassword").value;if(!l||!c){n.textContent="Select file and enter password",n.className="modal-message error";return}try{const d=await l.text(),r=await J.importOWI(d,c);r.success?(e._parsedSessions=r.data.sessions,n.textContent=`Verified! ${e._parsedSessions.length} sessions`,n.className="modal-message success"):(n.textContent=r.error,n.className="modal-message error")}catch{n.textContent="Decryption failed",n.className="modal-message error"}},e.querySelector("#rmRestore").onclick=async()=>{const l=e._parsedSessions||[];if(!l.length){n.textContent="No sessions to restore",n.className="modal-message error";return}const{data:c}=await b.getAll(),d=new Set(c.map(u=>u.timestamp)),r=l.filter(u=>!d.has(u.timestamp));for(const u of r)await b.save(u).catch(()=>{});n.textContent=`Restored ${r.length} of ${l.length} sessions`,n.className="modal-message success",document.dispatchEvent(new CustomEvent("seswi:sessions-restored")),setTimeout(()=>m.closeModal(e),1e3)}},_cleanTabData:{cookies:[],localStorage:{},sessionStorage:{},domain:""},async openCleanTab(){this._ensureCleanTabModal();const e=document.getElementById("cleanTabModal");e.querySelector("#ctMessage").textContent="",e.querySelectorAll('input[type="checkbox"]').forEach(n=>n.checked=!0),e.querySelector("#ctCache").checked=!1,e.querySelectorAll(".ct-data-preview").forEach(n=>n.classList.remove("show")),e.querySelectorAll(".ct-expand-icon").forEach(n=>n.classList.remove("expanded"));const{TabInfo:t,BrowserStorage:s}=await I(async()=>{const{TabInfo:n,BrowserStorage:i}=await Promise.resolve().then(()=>te);return{TabInfo:n,BrowserStorage:i}},void 0),{Cookies:o}=await I(async()=>{const{Cookies:n}=await Promise.resolve().then(()=>ce);return{Cookies:n}},void 0),a=await t.getCurrent();if(a.success){const n=a.data.tabId,i=a.data.domain,[l,c,d]=await Promise.all([o.getCurrentTab(),s.getLocal(n),s.getSession(n)]);let r=[];try{chrome.history?.search&&(r=(await chrome.history.search({text:i,maxResults:1e3,startTime:0})).filter(S=>{try{const P=new URL(S.url).hostname;return _.isMatch(i,P)}catch{return!1}}))}catch{}this._cleanTabData={cookies:l.data?.cookies||[],localStorage:c.data||{},sessionStorage:d.data||{},history:r,domain:i};const u=this._cleanTabData.cookies.length,f=Object.keys(this._cleanTabData.localStorage).length,h=Object.keys(this._cleanTabData.sessionStorage).length;e.querySelector("#ctCookieCount").textContent=u,e.querySelector("#ctLSCount").textContent=f,e.querySelector("#ctSSCount").textContent=h,e.querySelector("#ctHistoryCount").textContent=r.length||"—",e.querySelector("#ctHistoryPreview").innerHTML=this._renderCleanTabHistory(),e.querySelector("#ctDomainLabel").textContent=i,e.querySelector("#ctCookiePreview").innerHTML=this._renderCleanTabCookies(),e.querySelector("#ctLSPreview").innerHTML=this._renderCleanTabStorage("localStorage"),e.querySelector("#ctSSPreview").innerHTML=this._renderCleanTabStorage("sessionStorage")}e.style.display="block"},_renderCleanTabCookies(){const e=this._cleanTabData.cookies;return e.length?e.map(t=>{const s=[t.secure?"Secure":"",t.httpOnly?"HttpOnly":""].filter(Boolean).join(" · ")||"—",o=(t.value||"").slice(0,40)+((t.value||"").length>40?"...":"");let a="Session",n="session";if(!t.session&&t.expirationDate){const i=Date.now()/1e3,l=Math.ceil((t.expirationDate-i)/86400),c=new Date(t.expirationDate*1e3).toLocaleDateString();l<=0?(a="Expired",n="expired"):l<=7?(a=`${l}d left`,n="expired"):l<=30?(a=`${l}d left`,n="warning"):(a=c,n="valid")}return`
        <div class="ct-data-row">
          <div class="ct-data-header">
            <span class="ct-data-name">${m.escapeHtml(t.name||"")}</span>
            <span class="ct-data-exp ${n}">${a}</span>
          </div>
          <div class="ct-data-flags">${s}</div>
          <div class="ct-data-value">${m.escapeHtml(o)}</div>
        </div>
      `}).join(""):'<div class="empty-data-msg">No cookies</div>'},_renderCleanTabStorage(e){const t=e==="localStorage"?this._cleanTabData.localStorage:this._cleanTabData.sessionStorage,s=Object.entries(t);return s.length?s.slice(0,15).map(([o,a])=>{const n=typeof a=="string"?a:JSON.stringify(a),i=n.length>50?n.slice(0,47)+"...":n;return`
        <div class="ct-data-row">
          <div class="ct-data-name">${m.escapeHtml(o)}</div>
          <div class="ct-data-value">${m.escapeHtml(i)}</div>
        </div>
      `}).join("")+(s.length>15?`<div class="ct-more">+${s.length-15} more...</div>`:""):`<div class="empty-data-msg">No ${e}</div>`},_renderCleanTabHistory(){const e=this._cleanTabData.history||[];return e.length?[...e].sort((s,o)=>(o.lastVisitTime||0)-(s.lastVisitTime||0)).map(s=>{const o=s.title||"Untitled",a=o.length>40?o.slice(0,37)+"...":o,n=s.url||"",i=n.length>50?n.slice(0,47)+"...":n;let l="";if(s.lastVisitTime){const c=new Date(s.lastVisitTime),r=new Date-c,u=Math.floor(r/6e4),f=Math.floor(r/36e5),h=Math.floor(r/864e5);u<1?l="Just now":u<60?l=`${u}m ago`:f<24?l=`${f}h ago`:h<7?l=`${h}d ago`:l=c.toLocaleDateString()}return`
        <div class="ct-data-row ct-history-row">
          <div class="ct-data-header">
            <span class="ct-data-name">${m.escapeHtml(a)}</span>
            <span class="ct-data-time">${l}</span>
          </div>
          <div class="ct-data-url">${m.escapeHtml(i)}</div>
        </div>
      `}).join(""):'<div class="empty-data-msg">No history</div>'},_ensureCleanTabModal(){if(document.getElementById("cleanTabModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="cleanTabModal" class="modal">
        <div class="modal-content clean-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="ctTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-broom mr-2 text-red-500"></i>Clean Current Tab</h3>
          </div>
          <div class="modal-body">
            <p class="text-sm text-slate-600 mb-2">Data for <strong id="ctDomainLabel">—</strong></p>
            <div class="clean-options">
              <div class="clean-option-wrap">
                <label class="clean-option">
                  <input type="checkbox" id="ctCookies" checked>
                  <i class="fa-solid fa-cookie text-amber-500"></i>
                  <span class="clean-label">Cookies</span>
                  <span class="clean-count" id="ctCookieCount">-</span>
                  <i class="fa-solid fa-chevron-down ct-expand-icon" data-target="ctCookiePreview"></i>
                </label>
                <div class="ct-data-preview" id="ctCookiePreview"></div>
              </div>
              <div class="clean-option-wrap">
                <label class="clean-option">
                  <input type="checkbox" id="ctLocalStorage" checked>
                  <i class="fa-solid fa-database text-emerald-500"></i>
                  <span class="clean-label">localStorage</span>
                  <span class="clean-count" id="ctLSCount">-</span>
                  <i class="fa-solid fa-chevron-down ct-expand-icon" data-target="ctLSPreview"></i>
                </label>
                <div class="ct-data-preview" id="ctLSPreview"></div>
              </div>
              <div class="clean-option-wrap">
                <label class="clean-option">
                  <input type="checkbox" id="ctSessionStorage" checked>
                  <i class="fa-solid fa-hard-drive text-blue-500"></i>
                  <span class="clean-label">sessionStorage</span>
                  <span class="clean-count" id="ctSSCount">-</span>
                  <i class="fa-solid fa-chevron-down ct-expand-icon" data-target="ctSSPreview"></i>
                </label>
                <div class="ct-data-preview" id="ctSSPreview"></div>
              </div>
              <div class="clean-option-wrap">
                <label class="clean-option">
                  <input type="checkbox" id="ctHistory" checked>
                  <i class="fa-solid fa-clock-rotate-left text-violet-500"></i>
                  <span class="clean-label">History</span>
                  <span class="clean-count" id="ctHistoryCount">—</span>
                  <i class="fa-solid fa-chevron-down ct-expand-icon" data-target="ctHistoryPreview"></i>
                </label>
                <div class="ct-data-preview" id="ctHistoryPreview"></div>
              </div>
              <label class="clean-option">
                <input type="checkbox" id="ctCache">
                <i class="fa-solid fa-box text-slate-500"></i>
                <span class="clean-label">Cache</span>
                <span class="clean-count">—</span>
              </label>
            </div>
            <div class="modal-message" id="ctMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="ctCancel">Cancel</button>
            <button class="btn btn-danger" id="ctClean"><i class="fa-solid fa-trash mr-1"></i>Clean Selected</button>
          </div>
        </div>
      </div>
    `),this._wireCleanTabModal()},_wireCleanTabModal(){const e=document.getElementById("cleanTabModal"),t=e.querySelector("#ctMessage"),s=()=>m.closeModal(e);e.onclick=o=>{o.target===e&&s()},e.querySelector("#ctTlClose").onclick=s,e.querySelector("#ctCancel").onclick=s,e.querySelectorAll(".ct-expand-icon").forEach(o=>{o.onclick=a=>{a.preventDefault(),a.stopPropagation();const n=o.dataset.target,i=e.querySelector("#"+n);i&&(i.classList.toggle("show"),o.classList.toggle("expanded"))}}),e.querySelector("#ctClean").onclick=async()=>{const o={cookies:e.querySelector("#ctCookies").checked,localStorage:e.querySelector("#ctLocalStorage").checked,sessionStorage:e.querySelector("#ctSessionStorage").checked,history:e.querySelector("#ctHistory").checked,cache:e.querySelector("#ctCache").checked};if(Object.values(o).filter(Boolean).length===0){t.textContent="Select at least one option",t.className="modal-message error";return}t.textContent="Cleaning...",t.className="modal-message";try{const{TabInfo:n}=await I(async()=>{const{TabInfo:i}=await Promise.resolve().then(()=>te);return{TabInfo:i}},void 0);await n.cleanCurrentTab(o),t.textContent="Cleaned successfully!",t.className="modal-message success",setTimeout(()=>m.closeModal(e),800)}catch{t.textContent="Failed to clean",t.className="modal-message error"}}},async openGroupManage(){this._ensureGroupManageModal();const e=document.getElementById("groupManageModal"),t=e.querySelector("#gmList"),s=e.querySelector("#gmMessage");s.textContent="",s.className="modal-message";const{data:o}=await b.getGroupedByDomain();if(!o||o.length===0){t.innerHTML='<div class="empty-data-msg">No saved sessions</div>',e.style.display="block";return}e._groups=o,t.innerHTML=o.map(a=>{const n=a.sessions.reduce((l,c)=>l+(c.cookies?.length||0),0),i=a.sessions.map(l=>`
        <div class="gm-session" data-ts="${l.timestamp}">
          <input type="checkbox" class="gm-session-check" data-ts="${l.timestamp}" data-domain="${a.domain}">
          <div class="gm-session-info">
            <span class="gm-session-name">${m.escapeHtml(l.name)}</span>
            <span class="gm-session-meta">${l.cookies?.length||0} cookies</span>
          </div>
        </div>
      `).join("");return`
        <div class="gm-group" data-domain="${m.escapeHtml(a.domain)}">
          <div class="gm-group-header">
            <input type="checkbox" class="gm-domain-check" data-domain="${a.domain}" title="Select all in ${a.domain}">
            <span class="gm-group-toggle"><i class="fa-solid fa-chevron-right"></i></span>
            <div class="gm-group-info">
              <span class="gm-domain">${m.escapeHtml(a.domain)}</span>
              <span class="gm-stats">${n} cookies</span>
            </div>
            <span class="gm-session-count">${a.sessions.length}</span>
          </div>
          <div class="gm-group-sessions"><div class="gm-sessions-scroll">${i}</div></div>
        </div>
      `}).join(""),t.querySelectorAll(".gm-group-header").forEach(a=>{const n=a.closest(".gm-group");a.onclick=i=>{i.target.type!=="checkbox"&&n.classList.toggle("expanded")}}),t.querySelectorAll(".gm-domain-check").forEach(a=>{a.onchange=()=>{const n=a.dataset.domain,i=t.querySelector(`.gm-group[data-domain="${n}"]`);i.querySelectorAll(".gm-session-check").forEach(l=>{l.checked=a.checked,l.closest(".gm-session").classList.toggle("selected",a.checked)}),a.checked&&i.classList.add("expanded"),e._updateCount()}}),t.querySelectorAll(".gm-session-check").forEach(a=>{a.onchange=()=>{a.closest(".gm-session").classList.toggle("selected",a.checked);const n=a.dataset.domain,i=t.querySelector(`.gm-group[data-domain="${n}"]`),l=i.querySelectorAll(".gm-session-check"),c=i.querySelector(".gm-domain-check");c.checked=Array.from(l).every(d=>d.checked),c.indeterminate=!c.checked&&Array.from(l).some(d=>d.checked),e._updateCount()}}),t.querySelectorAll(".gm-session").forEach(a=>{a.onclick=n=>{if(n.target.type==="checkbox")return;const i=a.querySelector(".gm-session-check");i.checked=!i.checked,i.dispatchEvent(new Event("change"))}}),e.style.display="block"},_ensureGroupManageModal(){if(document.getElementById("groupManageModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="groupManageModal" class="modal">
        <div class="modal-content gm-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="gmTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-layer-group mr-2 text-slate-600"></i>Manage by Domain</h3>
          </div>
          <div class="modal-body">
            <div class="gm-toolbar">
              <button class="gm-select-all" id="gmSelectAll">Select All</button>
              <span class="gm-selected-count" id="gmSelectedCount">0 selected</span>
            </div>
            <div id="gmList" class="gm-list"></div>
            <div class="modal-message" id="gmMessage"></div>
          </div>
          <div class="modal-footer gm-footer">
            <button class="btn btn-secondary" id="gmCancel">Cancel</button>
            <button class="btn btn-secondary" id="gmBackupJSON"><i class="fa-solid fa-file-code mr-1"></i>JSON</button>
            <button class="btn btn-secondary" id="gmBackupOWI"><i class="fa-solid fa-lock mr-1"></i>OWI</button>
            <button class="btn btn-danger" id="gmDelete"><i class="fa-solid fa-trash mr-1"></i>Delete</button>
          </div>
        </div>
      </div>
    `),this._wireGroupManageModal()},_wireGroupManageModal(){const e=document.getElementById("groupManageModal"),t=e.querySelector("#gmMessage"),s=()=>m.closeModal(e);e.onclick=n=>{n.target===e&&s()},e.querySelector("#gmTlClose").onclick=s,e.querySelector("#gmCancel").onclick=s;const o=()=>Array.from(e.querySelectorAll(".gm-session-check:checked")).map(n=>parseInt(n.dataset.ts));e._updateCount=()=>{const n=o().length;e.querySelector("#gmSelectedCount").textContent=`${n} selected`},e.querySelector("#gmSelectAll").onclick=()=>{const n=e.querySelectorAll(".gm-session-check"),i=Array.from(n).every(l=>l.checked);n.forEach(l=>{l.checked=!i,l.closest(".gm-session").classList.toggle("selected",!i)}),e.querySelectorAll(".gm-domain-check").forEach(l=>{l.checked=!i,l.indeterminate=!1}),i||e.querySelectorAll(".gm-group").forEach(l=>l.classList.add("expanded")),e._updateCount()};const a=()=>{const n=new Set(o());return(e._groups||[]).flatMap(i=>i.sessions).filter(i=>n.has(i.timestamp))};e.querySelector("#gmBackupJSON").onclick=()=>{const n=a();if(!n.length){t.textContent="Select at least one session",t.className="modal-message error";return}m.downloadFile(JSON.stringify(n,null,2),`backup-${n.length}sessions.json`,"application/json"),t.textContent=`Exported ${n.length} sessions`,t.className="modal-message success"},e.querySelector("#gmBackupOWI").onclick=()=>{const n=a();if(!n.length){t.textContent="Select at least one session",t.className="modal-message error";return}this.openBatchOWIExport(n,`backup-${n.length}sessions`,()=>{t.textContent=`Exported ${n.length} sessions`,t.className="modal-message success"})},e.querySelector("#gmDelete").onclick=()=>{const n=o();if(!n.length){t.textContent="Select at least one session",t.className="modal-message error";return}this.openConfirm({title:"Delete Sessions",message:`Delete ${n.length} selected session(s)?`,confirmText:"Delete",confirmClass:"btn-danger",onConfirm:async()=>{const i=await b.deleteMany(n);t.textContent=i.success?`Deleted ${i.data.deleted} sessions`:i.error,t.className=i.success?"modal-message success":"modal-message error",i.success&&(document.dispatchEvent(new CustomEvent("seswi:sessions-deleted")),setTimeout(()=>m.closeModal(e),800))}})}},close(e){const t=document.getElementById(e);t&&m.closeModal(t)},async openDeleteExpired(){this._ensureDeleteExpiredModal();const e=document.getElementById("deleteExpiredModal"),t=e.querySelector("#deList"),s=e.querySelector("#deMessage"),o=e.querySelector("#deCount"),{data:a}=await b.getAll(),n=Date.now()/1e3,i=a.filter(l=>{const d=(l.cookies||[]).filter(u=>!u.session&&u.expirationDate);return d.length?Math.max(...d.map(u=>u.expirationDate))<=n:!1});o.textContent=i.length,i.length?(t.innerHTML=i.map(l=>{const d=B.getSessionExpiration(l.cookies)?.label||"Expired";return`
          <div class="de-item selected" data-ts="${l.timestamp}">
            <input type="checkbox" class="de-check" data-ts="${l.timestamp}" checked>
            <div class="de-info">
              <span class="de-name">${m.escapeHtml(l.name)}</span>
              <span class="de-domain">${m.escapeHtml(l.domain)}</span>
            </div>
            <span class="de-exp">${d}</span>
          </div>
        `}).join(""),t.querySelectorAll(".de-item").forEach(l=>{l.onclick=c=>{if(c.target.type!=="checkbox"){const d=l.querySelector(".de-check");d.checked=!d.checked}l.classList.toggle("selected",l.querySelector(".de-check").checked)}})):t.innerHTML='<div class="empty-data-msg"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i>No expired sessions found!</div>',s.textContent="",e.style.display="block"},_ensureDeleteExpiredModal(){if(document.getElementById("deleteExpiredModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="deleteExpiredModal" class="modal">
        <div class="modal-content de-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="deTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-trash-can mr-2 text-red-500"></i>Delete Expired</h3>
          </div>
          <div class="modal-body">
            <div class="de-summary">
              <i class="fa-solid fa-circle-exclamation text-red-500"></i>
              <span>Found <strong id="deCount">0</strong> expired sessions</span>
            </div>
            <div id="deList" class="de-list"></div>
            <div class="modal-message" id="deMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="deCancel">Cancel</button>
            <button class="btn btn-danger" id="deDelete"><i class="fa-solid fa-trash mr-1"></i>Delete Selected</button>
          </div>
        </div>
      </div>
    `),this._wireDeleteExpiredModal()},_wireDeleteExpiredModal(){const e=document.getElementById("deleteExpiredModal"),t=e.querySelector("#deMessage"),s=()=>m.closeModal(e);e.onclick=o=>{o.target===e&&s()},e.querySelector("#deTlClose").onclick=s,e.querySelector("#deCancel").onclick=s,e.querySelector("#deDelete").onclick=async()=>{const o=Array.from(e.querySelectorAll(".de-check:checked")).map(a=>parseInt(a.dataset.ts));if(!o.length){t.textContent="No sessions selected",t.className="modal-message error";return}this.openConfirm({title:"Delete Expired",message:`Delete ${o.length} expired session(s)?`,confirmText:"Delete",confirmClass:"btn-danger",onConfirm:async()=>{let a=0;for(const n of o)(await b.delete(n)).success&&a++;t.textContent=`Deleted ${a} sessions`,t.className="modal-message success",document.dispatchEvent(new CustomEvent("seswi:sessions-deleted")),setTimeout(()=>m.closeModal(e),800)}})}},openEditSession(e,t){this._ensureEditSessionModal();const s=document.getElementById("editSessionModal"),o=s.querySelector("#esName"),a=s.querySelector("#esMessage");o.value=e.name,s.querySelector("#esDomain").textContent=e.domain,a.textContent="",s._session=e,s._onSave=t,s.style.display="block",o.focus(),o.select()},_ensureEditSessionModal(){if(document.getElementById("editSessionModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="editSessionModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="esTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-pen mr-2 text-blue-500"></i>Edit Session</h3>
          </div>
          <div class="modal-body">
            <label class="text-xs text-slate-500 mb-1 block">Session Name</label>
            <input type="text" id="esName" placeholder="Session name..." maxlength="50">
            <div class="es-domain-row">
              <i class="fa-solid fa-globe text-slate-400"></i>
              <span id="esDomain">-</span>
            </div>
            <div class="modal-message" id="esMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="esCancel">Cancel</button>
            <button class="btn btn-primary" id="esSave"><i class="fa-solid fa-save mr-1"></i>Save</button>
          </div>
        </div>
      </div>
    `),this._wireEditSessionModal()},_wireEditSessionModal(){const e=document.getElementById("editSessionModal"),t=e.querySelector("#esName"),s=e.querySelector("#esMessage"),o=()=>m.closeModal(e);e.onclick=a=>{a.target===e&&o()},e.querySelector("#esTlClose").onclick=o,e.querySelector("#esCancel").onclick=o,e.querySelector("#esSave").onclick=async()=>{const a=t.value.trim();if(!a){s.textContent="Name cannot be empty",s.className="modal-message error";return}if(a===e._session.name){o();return}const n={...e._session,name:a},i=await b.update(n);i.success?(s.textContent="Saved!",s.className="modal-message success",e._onSave&&e._onSave(n),document.dispatchEvent(new CustomEvent("seswi:session-updated")),setTimeout(()=>m.closeModal(e),500)):(s.textContent=i.error||"Failed to save",s.className="modal-message error")},t.onkeydown=a=>{a.key==="Enter"&&e.querySelector("#esSave").click()}},openDeleteConfirm(e,t){this._ensureDeleteConfirmModal();const s=document.getElementById("deleteConfirmModal");s.querySelector("#dcName").textContent=e.name,s.querySelector("#dcDomain").textContent=e.domain,s.querySelector("#dcMessage").textContent="",s._onConfirm=t,s._session=e,s.style.display="block"},_ensureDeleteConfirmModal(){if(document.getElementById("deleteConfirmModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="deleteConfirmModal" class="modal">
        <div class="modal-content dc-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="dcTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-trash mr-2 text-red-500"></i>Delete Session</h3>
          </div>
          <div class="modal-body">
            <div class="dc-warning">
              <i class="fa-solid fa-triangle-exclamation text-amber-500"></i>
              <span>This action cannot be undone!</span>
            </div>
            <div class="dc-session-info">
              <div class="dc-info-row">
                <span class="dc-label">Session:</span>
                <span class="dc-value" id="dcName">-</span>
              </div>
              <div class="dc-info-row">
                <span class="dc-label">Domain:</span>
                <span class="dc-value" id="dcDomain">-</span>
              </div>
            </div>
            <div class="modal-message" id="dcMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="dcCancel">Cancel</button>
            <button class="btn btn-danger" id="dcConfirm"><i class="fa-solid fa-trash mr-1"></i>Delete</button>
          </div>
        </div>
      </div>
    `),this._wireDeleteConfirmModal()},_wireDeleteConfirmModal(){const e=document.getElementById("deleteConfirmModal"),t=e.querySelector("#dcMessage"),s=()=>m.closeModal(e);e.onclick=o=>{o.target===e&&s()},e.querySelector("#dcTlClose").onclick=s,e.querySelector("#dcCancel").onclick=s,e.querySelector("#dcConfirm").onclick=async()=>{t.textContent="Deleting...",t.className="modal-message";const o=await b.delete(e._session.timestamp);o.success?(t.textContent="Deleted!",t.className="modal-message success",e._onConfirm&&e._onConfirm(),document.dispatchEvent(new CustomEvent("seswi:session-deleted")),setTimeout(s,300)):(t.textContent=o.error||"Failed to delete",t.className="modal-message error")}},openReplaceConfirm(e,t){this._ensureReplaceConfirmModal();const s=document.getElementById("replaceConfirmModal");s.querySelector("#rcName").textContent=e.name,s.querySelector("#rcDomain").textContent=e.domain,s.querySelector("#rcMessage").textContent="",s._onConfirm=t,s._session=e,s.style.display="block"},_ensureReplaceConfirmModal(){if(document.getElementById("replaceConfirmModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="replaceConfirmModal" class="modal">
        <div class="modal-content rc-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="rcTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-arrows-rotate mr-2 text-amber-500"></i>Replace Session</h3>
          </div>
          <div class="modal-body">
            <div class="rc-warning">
              <i class="fa-solid fa-triangle-exclamation text-amber-500"></i>
              <span>Current session data will be replaced!</span>
            </div>
            <div class="rc-session-info">
              <div class="rc-info-row">
                <span class="rc-label">Session:</span>
                <span class="rc-value" id="rcName">-</span>
              </div>
              <div class="rc-info-row">
                <span class="rc-label">Domain:</span>
                <span class="rc-value" id="rcDomain">-</span>
              </div>
            </div>
            <p class="rc-desc">This will delete the saved session and save fresh data from the current tab.</p>
            <div class="modal-message" id="rcMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="rcCancel">Cancel</button>
            <button class="btn btn-amber" id="rcConfirm"><i class="fa-solid fa-arrows-rotate mr-1"></i>Replace</button>
          </div>
        </div>
      </div>
    `),this._wireReplaceConfirmModal()},_wireReplaceConfirmModal(){const e=document.getElementById("replaceConfirmModal"),t=e.querySelector("#rcMessage"),s=()=>m.closeModal(e);e.onclick=o=>{o.target===e&&s()},e.querySelector("#rcTlClose").onclick=s,e.querySelector("#rcCancel").onclick=s,e.querySelector("#rcConfirm").onclick=async()=>{t.textContent="Replacing...",t.className="modal-message";const o=e._session;await b.delete(o.timestamp);const{CurrentTab:a}=await I(async()=>{const{CurrentTab:i}=await Promise.resolve().then(()=>de);return{CurrentTab:i}},void 0),n=await a.handleAddSession(o.name);if(n.success){const i={...n.data,index:o.index,originalUrl:o.originalUrl};await b.update(i),t.textContent="Replaced!",t.className="modal-message success",e._onConfirm&&e._onConfirm(),document.dispatchEvent(new CustomEvent("seswi:session-replaced")),setTimeout(s,500)}else t.textContent=n.error||"Failed to replace",t.className="modal-message error"}},openOWIExport(e,t){this._ensureOWIExportModal();const s=document.getElementById("owiExportModal");s.querySelector("#oeName").textContent=e.name,s.querySelector("#oeDomain").textContent=e.domain,s.querySelector("#oePassword").value="",s.querySelector("#oeMessage").textContent="",s._session=e,s._onSuccess=t,s.style.display="block",s.querySelector("#oePassword").focus()},_ensureOWIExportModal(){if(document.getElementById("owiExportModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="owiExportModal" class="modal">
        <div class="modal-content oe-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="oeTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-lock mr-2 text-violet-500"></i>Export OWI</h3>
          </div>
          <div class="modal-body">
            <div class="oe-session-info">
              <div class="oe-info-row">
                <span class="oe-label">Session:</span>
                <span class="oe-value" id="oeName">-</span>
              </div>
              <div class="oe-info-row">
                <span class="oe-label">Domain:</span>
                <span class="oe-value" id="oeDomain">-</span>
              </div>
            </div>
            <div class="oe-password-field">
              <label class="oe-password-label">Encryption Password</label>
              <div class="oe-password-wrap">
                <input type="password" id="oePassword" placeholder="Enter password..." autocomplete="new-password">
                <button type="button" class="oe-toggle-pwd" id="oeTogglePwd"><i class="fa-solid fa-eye"></i></button>
              </div>
              <p class="oe-password-hint">Password is required to decrypt the file later</p>
            </div>
            <div class="modal-message" id="oeMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="oeCancel">Cancel</button>
            <button class="btn btn-violet" id="oeExport"><i class="fa-solid fa-download mr-1"></i>Export OWI</button>
          </div>
        </div>
      </div>
    `),this._wireOWIExportModal()},_wireOWIExportModal(){this._wireOWIModal(document.getElementById("owiExportModal"),{close:"oeTlClose",cancel:"oeCancel",toggle:"oeTogglePwd",pwd:"oePassword",export:"oeExport",msg:"oeMessage"},e=>{const t=e._session;return J.exportOWI([t],e.querySelector("#oePassword").value.trim(),`${t.domain}-${t.name}`)})},openBatchOWIExport(e,t,s){this._ensureBatchOWIModal();const o=document.getElementById("batchOWIModal");o.querySelector("#boeCount").textContent=e.length,o.querySelector("#boeFilename").textContent=t,o.querySelector("#boePassword").value="",o.querySelector("#boeMessage").textContent="",o._sessions=e,o._filename=t,o._onSuccess=s,o.style.display="block",o.querySelector("#boePassword").focus()},_ensureBatchOWIModal(){if(document.getElementById("batchOWIModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="batchOWIModal" class="modal">
        <div class="modal-content oe-modal">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="boeTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-file-shield mr-2 text-violet-500"></i>Batch Export OWI</h3>
          </div>
          <div class="modal-body">
            <div class="oe-session-info">
              <div class="oe-info-row">
                <span class="oe-label">Sessions:</span>
                <span class="oe-value" id="boeCount">-</span>
              </div>
              <div class="oe-info-row">
                <span class="oe-label">Filename:</span>
                <span class="oe-value" id="boeFilename">-</span>
              </div>
            </div>
            <div class="oe-password-field">
              <label class="oe-password-label">Encryption Password</label>
              <div class="oe-password-wrap">
                <input type="password" id="boePassword" placeholder="Enter password..." autocomplete="new-password">
                <button type="button" class="oe-toggle-pwd" id="boeTogglePwd"><i class="fa-solid fa-eye"></i></button>
              </div>
              <p class="oe-password-hint">Password is required to decrypt the backup file</p>
            </div>
            <div class="modal-message" id="boeMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="boeCancel">Cancel</button>
            <button class="btn btn-violet" id="boeExport"><i class="fa-solid fa-download mr-1"></i>Export OWI</button>
          </div>
        </div>
      </div>
    `),this._wireBatchOWIModal()},_wireBatchOWIModal(){this._wireOWIModal(document.getElementById("batchOWIModal"),{close:"boeTlClose",cancel:"boeCancel",toggle:"boeTogglePwd",pwd:"boePassword",export:"boeExport",msg:"boeMessage"},e=>J.exportOWI(e._sessions,e.querySelector("#boePassword").value.trim(),e._filename))},_wireOWIModal(e,t,s){const o=e.querySelector(`#${t.msg}`),a=e.querySelector(`#${t.pwd}`),n=()=>m.closeModal(e);e.onclick=i=>{i.target===e&&n()},e.querySelector(`#${t.close}`).onclick=n,e.querySelector(`#${t.cancel}`).onclick=n,e.querySelector(`#${t.toggle}`).onclick=()=>{const i=a.type==="password";a.type=i?"text":"password",e.querySelector(`#${t.toggle} i`).className=i?"fa-solid fa-eye-slash":"fa-solid fa-eye"},a.onkeydown=i=>{i.key==="Enter"&&e.querySelector(`#${t.export}`).click()},e.querySelector(`#${t.export}`).onclick=async()=>{const i=a.value.trim();if(!i){o.textContent="Please enter a password",o.className="modal-message error";return}if(i.length<4){o.textContent="Password must be at least 4 characters",o.className="modal-message error";return}o.textContent="Encrypting...",o.className="modal-message";const l=await s(e);l.success?(o.textContent="Exported!",o.className="modal-message success",e._onSuccess&&e._onSuccess(),setTimeout(n,500)):(o.textContent=l.error||"Failed to export",o.className="modal-message error")}},openQuickAction(){this._ensureQuickActionModal();const e=document.getElementById("quickActionModal");e.style.display="block"},_ensureQuickActionModal(){if(document.getElementById("quickActionModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="quickActionModal" class="modal">
        <div class="modal-content" style="width: 340px;">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="qaTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3><i class="fa-solid fa-bolt mr-2 text-amber-500"></i>Export Tab Data</h3>
          </div>
          <div class="modal-body">
            <div class="qa-desc-row">
              <i class="fa-solid fa-circle-info text-slate-400"></i>
              <span>Export session data from the current tab without saving.</span>
            </div>
            <div class="qa-export-grid">
              <button class="qa-export-btn" id="qaCopyJSON">
                <span class="qa-export-icon" style="background:#f0fdf4;color:#16a34a;">
                  <i class="fa-solid fa-clipboard"></i>
                </span>
                <div class="qa-export-text">
                  <div class="qa-export-title">Copy JSON</div>
                  <div class="qa-export-desc">Copy to clipboard</div>
                </div>
              </button>
              <button class="qa-export-btn" id="qaJSON">
                <span class="qa-export-icon" style="background:#fef3c7;color:#d97706;">
                  <i class="fa-solid fa-file-code"></i>
                </span>
                <div class="qa-export-text">
                  <div class="qa-export-title">Export JSON File</div>
                  <div class="qa-export-desc">Raw cookie array</div>
                </div>
              </button>
              <button class="qa-export-btn" id="qaNetscape">
                <span class="qa-export-icon" style="background:#dbeafe;color:#2563eb;">
                  <i class="fa-solid fa-file-lines"></i>
                </span>
                <div class="qa-export-text">
                  <div class="qa-export-title">Export Netscape File</div>
                  <div class="qa-export-desc">Browser-compatible format</div>
                </div>
              </button>
            </div>
            <div class="modal-message" id="qaMessage"></div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="qaCancel">Close</button>
          </div>
        </div>
      </div>
    `),this._wireQuickActionModal()},_wireQuickActionModal(){const e=document.getElementById("quickActionModal"),t=e.querySelector("#qaMessage"),s=()=>m.closeModal(e);e.onclick=a=>{a.target===e&&s()},e.querySelector("#qaTlClose").onclick=s,e.querySelector("#qaCancel").onclick=s;const o=async a=>{const{ManageTab:n}=await I(async()=>{const{ManageTab:i}=await Promise.resolve().then(()=>de);return{ManageTab:i}},void 0);n.handleExportCurrent(a),s()};e.querySelector("#qaCopyJSON").onclick=async()=>{const{TabInfo:a,BrowserStorage:n}=await I(async()=>{const{TabInfo:h,BrowserStorage:C}=await Promise.resolve().then(()=>te);return{TabInfo:h,BrowserStorage:C}},void 0),{Cookies:i}=await I(async()=>{const{Cookies:h}=await Promise.resolve().then(()=>ce);return{Cookies:h}},void 0),l=await a.getCurrent(),c=await i.getCurrentTab(),d=l.data?.tabId,[r,u]=await Promise.all([d?n.getLocal(d):Promise.resolve({data:{}}),d?n.getSession(d):Promise.resolve({data:{}})]),f={cookies:c.data?.cookies||[],localStorage:r.data||{},sessionStorage:u.data||{}};await navigator.clipboard.writeText(JSON.stringify(f,null,2)),t.textContent="Copied to clipboard!",t.className="modal-message success",setTimeout(()=>{t.textContent="",t.className="modal-message"},1500)},e.querySelector("#qaJSON").onclick=()=>o("json"),e.querySelector("#qaNetscape").onclick=()=>o("netscape")},openConfirm({title:e,message:t,confirmText:s,confirmClass:o,onConfirm:a}){this._ensureSimpleConfirmModal();const n=document.getElementById("simpleConfirmModal");n.querySelector("#scmTitle").textContent=e||"Confirm",n.querySelector("#scmMessage").textContent=t||"Are you sure?";const i=n.querySelector("#scmConfirm");i.textContent=s||"Confirm",i.className=`btn ${o||"btn-primary"}`,n._onConfirm=a,n.style.display="block"},_ensureSimpleConfirmModal(){if(document.getElementById("simpleConfirmModal"))return;document.body.insertAdjacentHTML("beforeend",`
      <div id="simpleConfirmModal" class="modal">
        <div class="modal-content scm-modal" style="width: 320px;">
          <div class="modal-header">
            <div class="traffic-lights">
              <span class="tl-btn tl-close" id="scmTlClose"></span>
              <span class="tl-btn tl-minimize"></span>
              <span class="tl-btn tl-maximize"></span>
            </div>
            <h3 id="scmTitle">Confirm</h3>
          </div>
          <div class="modal-body">
            <div style="padding: 10px 0;">
              <p id="scmMessage" style="font-size: 13px; color: #374151; line-height: 1.5; text-align: center;"></p>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" id="scmCancel">Cancel</button>
            <button class="btn btn-primary" id="scmConfirm">Confirm</button>
          </div>
        </div>
      </div>
    `),this._wireSimpleConfirmModal()},_wireSimpleConfirmModal(){const e=document.getElementById("simpleConfirmModal"),t=()=>m.closeModal(e);e.onclick=s=>{s.target===e&&t()},e.querySelector("#scmTlClose").onclick=t,e.querySelector("#scmCancel").onclick=t,e.querySelector("#scmConfirm").onclick=()=>{e._onConfirm&&e._onConfirm(),t()}}},Q=Object.freeze(Object.defineProperty({__proto__:null,Modal:M},Symbol.toStringTag,{value:"Module"})),me={sessionCard(e,t={}){const{showIndex:s=!0,index:o=1,highlight:a=!1}=t,n=e.cookies?.length||0,i=B.getSessionExpiration(e.cookies);let l="";return i&&(i.status==="valid"?l=`<span class="exp-badge valid" title="Valid for ${i.days} days"><i class="fa-solid ${i.icon}"></i>${i.label}</span>`:i.label&&(l=`<span class="exp-badge ${i.status}" title="Cookie expires in ${i.days||0} days"><i class="fa-solid ${i.icon}"></i>${i.label}</span>`)),`
      <div class="session-card${a?" just-saved":""}" data-ts="${e.timestamp}">
        <div class="session-header">
          ${s?`<span class="session-index">${o}</span>`:""}
          <span class="session-name">${m.escapeHtml(e.name)}</span>
          ${l}
        </div>
        <div class="session-meta">
          <span class="session-time">${B.formatRelative(e.timestamp)}</span>
          <span class="session-cookie-count"><i class="fa-solid fa-cookie-bite"></i>${n}</span>
        </div>
      </div>
    `}},D={page:1,perPage:5,justSavedTs:null,searchQuery:"",_totalPages:1,_wheelAttached:!1,async render(){const e=document.getElementById("currentSessionsContainer"),t=document.getElementById("currentPagination");if(e)try{const s=await O.getCurrent();if(!s.success)throw new Error("No tab info");const o=await b.getByDomain(s.data.domain);if(!o.success)throw new Error(o.error);let a=o.data||[];if(this.searchQuery.trim()){const i=this.searchQuery.toLowerCase();a=a.filter(l=>l.name.toLowerCase().includes(i)||l.domain.toLowerCase().includes(i))}if(a.length===0){const i=this.searchQuery.trim()?`No sessions matching "${m.escapeHtml(this.searchQuery)}"`:"No sessions for this domain";e.innerHTML=`<div class="empty-state"><p>${i}</p></div>`,t&&(t.innerHTML="");return}this._totalPages=K.getTotalPages(a,this.perPage),this.page>this._totalPages&&(this.page=this._totalPages);const n=K.getPage(a,this.page,this.perPage);e.innerHTML=n.map((i,l)=>{const c=(this.page-1)*this.perPage+l+1;return me.sessionCard(i,{index:c,highlight:this.justSavedTs===String(i.timestamp)})}).join(""),t&&(t.innerHTML=this._renderPagination(this._totalPages),this._wirePagination(t)),e.querySelectorAll(".session-card").forEach(i=>{i.onclick=()=>{const l=i.dataset.ts,c=a.find(d=>String(d.timestamp)===l);c&&M.openSessionActions(c)}}),this._attachWheelScroll()}catch(s){e.innerHTML=`<div class="error-state"><p>Error: ${m.escapeHtml(s.message)}</p></div>`}},_renderPagination(e){return e<=1?"":`
      <div class="pagination">
        <button class="page-btn" data-page="${this.page-1}" ${this.page<=1?"disabled":""}>‹</button>
        <span>${this.page} / ${e}</span>
        <button class="page-btn" data-page="${this.page+1}" ${this.page>=e?"disabled":""}>›</button>
      </div>
    `},_wirePagination(e){e.querySelectorAll(".page-btn").forEach(t=>{t.onclick=()=>{const s=parseInt(t.dataset.page);s&&!t.disabled&&(this.page=s,this.render())}})},_attachWheelScroll(){if(this._wheelAttached)return;const e=document.getElementById("current-session");e&&(e.addEventListener("wheel",t=>{this._totalPages<=1||(t.preventDefault(),t.deltaY<0&&this.page>1?(this.page--,this.render()):t.deltaY>0&&this.page<this._totalPages&&(this.page++,this.render()))},{passive:!1}),this._wheelAttached=!0)},async handleAddSession(e,t={}){const{saveLocalStorage:s=!0,saveSessionStorage:o=!0}=t;try{const a=await O.getCurrent();if(!a.success)return p.error("No tab info");const n=await R.getCurrentTab(),i=n.data?.cookies||[],l=n.data?.domain||a.data?.domain;if(!l)return p.error("No domain detected");let c={},d={};if(s||o){const[L,T]=await Promise.all([s?N.getLocal(a.data.tabId):Promise.resolve({data:{}}),o?N.getSession(a.data.tabId):Promise.resolve({data:{}})]);c=L.data||{},d=T.data||{}}if(!(i.length>0||Object.keys(c).length>0||Object.keys(d).length>0))return p.error("No data to save (cookies, localStorage, or sessionStorage)");const{data:u}=await b.getAll(),f=u.filter(L=>L.domain===l),h=f.length?Math.max(...f.map(L=>L.index||0)):0,C=Date.now(),S={name:e.trim(),domain:l,originalUrl:n.data?.url||a.data?.url,cookies:i,localStorage:c,sessionStorage:d,timestamp:C,index:h+1},P=await b.save(S);return P.success&&(this.justSavedTs=String(C),this.page=1,await this.render(),setTimeout(()=>{this.justSavedTs=null,this.render()},3e3)),P}catch(a){return p.error(a,"CurrentTab.handleAddSession")}}},W={expandedDomain:{},domainPages:{},searchQuery:"",async render(){const e=document.getElementById("groupSessionsContainer");if(e)try{const t=await b.getGroupedByDomain();if(!t.success)throw new Error(t.error);let s=t.data||[];const o=s.length,a=s.reduce((c,d)=>c+d.sessions.length,0),n=document.getElementById("overviewDomains"),i=document.getElementById("overviewSessions");if(n&&(n.textContent=o),i&&(i.textContent=a),this.searchQuery.trim()){const c=this.searchQuery.toLowerCase();s=s.map(d=>({...d,sessions:d.sessions.filter(r=>r.name.toLowerCase().includes(c)||r.domain.toLowerCase().includes(c))})).filter(d=>d.sessions.length>0)}if(s.length===0){const c=this.searchQuery.trim()?`No sessions matching "${m.escapeHtml(this.searchQuery)}"`:"No sessions saved yet";e.innerHTML=`<div class="empty-state"><p>${c}</p></div>`;return}const l=await Y.refresh();e.innerHTML=s.map(c=>this._renderDomainCard(c,l)).join(""),this._wireHandlers(e,s)}catch(t){e.innerHTML=`<div class="error-state"><p>Error: ${m.escapeHtml(t.message)}</p></div>`}},_renderDomainCard(e,t={}){const{domain:s,sessions:o}=e,a=this.expandedDomain[s]===!0,n=o.reduce((r,u)=>r+(u.cookies?.length||0),0),i=t[s]||Y.getFaviconUrl(s),l=o.reduce((r,u)=>u.timestamp>r.timestamp?u:r,o[0]),c=l?B.getSessionExpiration(l.cookies):null,d=c?.label?`<span class="exp-badge ${c.status}"><i class="fa-solid ${c.icon}"></i>${c.label}</span>`:c?.status==="valid"?'<span class="exp-badge valid"><i class="fa-solid fa-circle-check"></i></span>':"";return`
      <div class="domain-card${a?" expanded":""}" data-domain="${s}">
        <div class="domain-card-header">
          <div class="domain-card-left">
            <img class="domain-favicon" src="${i}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <span class="domain-favicon-fallback"><i class="fa-solid fa-globe"></i></span>
            <div class="domain-info">
              <span class="domain-name">${m.escapeHtml(s)}</span>
              <span class="domain-meta">${o.length} sessions · ${n} cookies</span>
            </div>
          </div>
          <div class="domain-card-right">
            ${d}
            <i class="fa-solid fa-chevron-${a?"down":"right"} text-slate-400 text-xs"></i>
          </div>
        </div>
        <div class="domain-card-content" style="display:${a?"block":"none"}">
          ${a?this._renderSessions(o,s):""}
        </div>
      </div>
    `},_renderSessions(e,t){const s=this.domainPages[t]||1,o=4,a=K.getPage(e,s,o),n=K.getTotalPages(e,o);return a.map((i,l)=>me.sessionCard(i,{index:(s-1)*o+l+1,showIndex:!0})).join("")+(n>1?`
      <div class="pagination">
        <button class="dpage-btn" data-domain="${t}" data-page="${s-1}" ${s<=1?"disabled":""}>‹</button>
        <span>${s}/${n}</span>
        <button class="dpage-btn" data-domain="${t}" data-page="${s+1}" ${s>=n?"disabled":""}>›</button>
      </div>
    `:"")},_wireHandlers(e,t){e.querySelectorAll(".domain-favicon").forEach(s=>{s.onerror=()=>{s.style.display="none";const o=s.nextElementSibling;o&&(o.style.display="flex")}}),e.querySelectorAll(".domain-card-header").forEach(s=>{s.onclick=()=>{const o=s.closest(".domain-card").dataset.domain;this.expandedDomain[o]=!this.expandedDomain[o],this.render()}}),e.querySelectorAll(".session-card").forEach(s=>{s.onclick=o=>{o.stopPropagation();const a=s.dataset.ts;let n=null;for(const i of t)if(n=i.sessions.find(l=>String(l.timestamp)===a),n)break;n&&M.openSessionActions(n)}}),e.querySelectorAll(".dpage-btn").forEach(s=>{s.onclick=o=>{o.stopPropagation();const a=s.dataset.domain,n=parseInt(s.dataset.page);n&&!s.disabled&&(this.domainPages[a]=n,this.render())}})}},ue={init(){document.getElementById("backupAll")?.addEventListener("click",()=>this.handleBackup()),document.getElementById("restoreSessions")?.addEventListener("click",()=>this.handleRestore()),document.getElementById("groupManage")?.addEventListener("click",()=>this.handleGroupManage()),document.getElementById("cleanCurrentTabData")?.addEventListener("click",()=>this.handleClean()),document.getElementById("deleteExpiredSessions")?.addEventListener("click",()=>this.handleDeleteExpired()),document.getElementById("quickAction")?.addEventListener("click",()=>M.openQuickAction())},async handleExportCurrent(e){try{const t=await O.getCurrent(),s=await R.getCurrentTab();if(!s.success){M.openConfirm({title:"Export Error",message:"Failed to get cookies: "+s.error,confirmText:"OK",onConfirm:()=>{}});return}const o=s.data?.cookies||[],a=s.data?.domain||"unknown",n=t.data?.tabId;if(e==="json"){const[i,l]=await Promise.all([n?N.getLocal(n):Promise.resolve({data:{}}),n?N.getSession(n):Promise.resolve({data:{}})]),c={cookies:o,localStorage:i.data||{},sessionStorage:l.data||{}};m.downloadFile(JSON.stringify(c,null,2),`${a}_session.json`,"application/json")}else{if(o.length===0){M.openConfirm({title:"No Data",message:"No cookies found for this tab.",confirmText:"OK",onConfirm:()=>{}});return}m.downloadFile(Se.toNetscape(o),`${a}_cookies_netscape.txt`,"text/plain")}}catch(t){console.error("Export failed:",t),M.openConfirm({title:"Export Failed",message:t.message,confirmText:"OK",onConfirm:()=>{}})}},handleBackup(){M.openBackupFormat()},handleRestore(){M.openRestore()},handleGroupManage(){M.openGroupManage()},handleClean(){M.openCleanTab()},handleDeleteExpired(){M.openDeleteExpired()}},de=Object.freeze(Object.defineProperty({__proto__:null,CurrentTab:D,GroupTab:W,ManageTab:ue},Symbol.toStringTag,{value:"Module"}));document.addEventListener("DOMContentLoaded",async()=>{const e=chrome.runtime.getManifest(),t=document.getElementById("appVersion");t&&(t.textContent=`v${e.version}`),await Le(),await De(),$e(),await D.render(),await W.render(),ue.init(),Be();const s=()=>{D.render(),W.render()};document.addEventListener("seswi:session-updated",s),document.addEventListener("seswi:session-deleted",s),document.addEventListener("seswi:session-replaced",s),document.addEventListener("seswi:sessions-restored",s),document.addEventListener("seswi:sessions-deleted",s)});async function Le(){const e=document.querySelectorAll(".tab-btn"),t=document.querySelectorAll(".tab-content");e.forEach(s=>{s.onclick=()=>{const o=s.dataset.tab;e.forEach(a=>a.classList.toggle("active",a===s)),t.forEach(a=>a.classList.toggle("active",a.id===o)),o==="current-session"&&D.render(),o==="group-sessions"&&W.render()}})}function $e(){m.debounceInput(document.getElementById("currentSearchInput"),e=>{D.searchQuery=e,D.page=1,D.render()}),m.debounceInput(document.getElementById("groupSearchInput"),e=>{W.searchQuery=e,W.render()})}async function De(){const e=document.getElementById("currentDomain"),t=await O.getCurrent();t.success&&e&&(e.textContent=t.data.domain||"Unknown")}function Be(){const e=document.getElementById("addSessionModal"),t=document.getElementById("sessionNameInput"),s=document.getElementById("addModalMessage");let o="capture";const a=document.getElementById("addPaneCapture"),n=document.getElementById("addPaneImport"),i=document.getElementById("addPaneFile"),l=g=>{o=g,["capture","import","file"].forEach(w=>{document.getElementById(`addMode${w.charAt(0).toUpperCase()+w.slice(1)}`).classList.toggle("active",w===g)}),a.classList.toggle("hidden",g!=="capture"),n.classList.toggle("hidden",g!=="import"),i.classList.toggle("hidden",g!=="file"),s.textContent="",s.style.display="none"};document.getElementById("addModeCapture").onclick=()=>{l("capture"),t.focus()},document.getElementById("addModeImport").onclick=()=>{l("import"),document.getElementById("importSessionName").focus()},document.getElementById("addModeFile").onclick=()=>l("file");const c=document.getElementById("addFileDrop"),d=document.getElementById("addFileInput"),r=document.getElementById("addFileList"),u=document.getElementById("addFilePwdWrap");let f=[],h=null;c.onclick=()=>d.click(),c.ondragover=g=>{g.preventDefault(),c.classList.add("dragover")},c.ondragleave=()=>c.classList.remove("dragover"),c.ondrop=g=>{g.preventDefault(),c.classList.remove("dragover"),g.dataTransfer.files?.length&&(d.files=g.dataTransfer.files,d.dispatchEvent(new Event("change")))},d.onchange=async()=>{const g=Array.from(d.files||[]);if(!g.length)return;f=[],h=null,r.innerHTML="",s.textContent="",s.style.display="none";const w=g.filter(y=>y.name.toLowerCase().endsWith(".owi")),v=g.filter(y=>y.name.toLowerCase().endsWith(".json"));if(w.length>0)h=w[0],u.classList.remove("hidden"),c.querySelector("span").innerHTML=`<i class="fa-solid fa-lock mr-1"></i>${m.escapeHtml(h.name)}`;else if(v.length>0){u.classList.add("hidden"),c.querySelector("span").innerHTML=`<i class="fa-solid fa-file-code mr-1"></i>${v.length} file(s) selected`;for(const y of v)try{const q=JSON.parse(await y.text()),x=z.importSessions(q);f.push(...x),r.insertAdjacentHTML("beforeend",`<div class="rm-file-item success"><i class="fa-solid fa-check"></i>${m.escapeHtml(y.name)} <span>(${x.length})</span></div>`)}catch{r.insertAdjacentHTML("beforeend",`<div class="rm-file-item error"><i class="fa-solid fa-xmark"></i>${m.escapeHtml(y.name)} <span>Invalid</span></div>`)}}},document.getElementById("addFileVerify").onclick=async()=>{const{Crypto:g}=await I(async()=>{const{Crypto:v}=await Promise.resolve().then(()=>we);return{Crypto:v}},void 0),w=document.getElementById("addFilePassword").value;if(!h||!w){s.textContent="Select file and enter password",s.style.display="block";return}try{const v=await g.importOWI(await h.text(),w);v.success?(f=v.data.sessions,s.textContent=`Verified! ${f.length} sessions ready`,s.className="modal-message success",s.style.display="block"):(s.textContent=v.error,s.className="modal-message error",s.style.display="block")}catch{s.textContent="Decryption failed",s.className="modal-message error",s.style.display="block"}};const C=document.getElementById("importCookieInput"),S=document.getElementById("importPreview"),P=document.getElementById("importPreviewText");m.debounceInput(C,g=>{if(!g.trim()){S.classList.add("hidden");return}try{const w=JSON.parse(g),v=z.importSessions(w),y=v.reduce((q,x)=>q+(x.cookies?.length||0),0);P.textContent=`${y} cookies · domain: ${v[0]?.domain||"?"}`,S.classList.remove("hidden"),S.querySelector("i").className="fa-solid fa-circle-check text-emerald-500"}catch{P.textContent="Invalid JSON",S.classList.remove("hidden"),S.querySelector("i").className="fa-solid fa-circle-xmark text-red-500"}},300);const L=async()=>{l("capture");const g=await O.getCurrent(),w=await R.getCurrentTab(),v=g.data?.domain||"-",y=g.data?.tabId,[q,x]=await Promise.all([y?N.getLocal(y):Promise.resolve({data:{}}),y?N.getSession(y):Promise.resolve({data:{}})]),k=w.data?.cookies?.length||0,$=Object.keys(q.data||{}).length,X=Object.keys(x.data||{}).length;document.getElementById("modalDomain").textContent=v,document.getElementById("modalCookies").textContent=k,document.getElementById("modalLocalStorage").textContent=$,document.getElementById("modalSessionStorage").textContent=X,document.getElementById("statCookies").title=`${k} cookies`,document.getElementById("statLocalStorage").title=`${$} localStorage items`,document.getElementById("statSessionStorage").title=`${X} sessionStorage items`;const A=document.getElementById("modalFavicon"),V=A?.nextElementSibling;if(A&&v!=="-"){const ge=Y.getFaviconUrl(v,g.data?.url);A.onerror=()=>{A.style.display="none",V&&(V.style.display="flex")},A.onload=()=>{A.style.display="block",V&&(V.style.display="none")},A.src=ge}const se=document.getElementById("domainWarning"),pe=document.getElementById("domainWarningText");_.isSensitive(v)?(se.classList.remove("hidden"),pe.textContent=`${v} uses complex auth. Saving/restoring may not work properly.`):se.classList.add("hidden"),t.value="",document.getElementById("importSessionName").value="",document.getElementById("importCookieInput").value="",S.classList.add("hidden"),f=[],h=null,d.value="",r.innerHTML="",u.classList.add("hidden"),document.getElementById("addFilePassword").value="",c.querySelector("span").innerHTML='<i class="fa-solid fa-folder-open mr-1"></i>Drop .json or .owi file(s)',document.getElementById("saveLocalStorage").checked=!0,document.getElementById("saveSessionStorage").checked=!0,document.getElementById("clearAfterSave").checked=!1,document.getElementById("clearInfoText")?.classList.add("hidden"),document.getElementById("statsInfoText")?.classList.add("hidden"),s.textContent="",s.style.display="none",e.style.display="block",t.focus()},T=()=>{e.style.display="none"},Z=async()=>{if(s.textContent="Saving...",s.className="modal-message",s.style.display="block",o==="import"){const y=document.getElementById("importSessionName").value.trim(),q=document.getElementById("importCookieInput").value.trim();if(!y){s.textContent="Please enter a name",s.style.display="block";return}if(!q){s.textContent="Please paste cookie JSON",s.style.display="block";return}let x;try{const $=JSON.parse(q);x=z.importSessions($,{name:y})}catch{s.textContent="Invalid JSON",s.className="modal-message error";return}if(!x.length||!x[0].cookies?.length){s.textContent="No cookies found in pasted data",s.className="modal-message error";return}let k=0;for(const $ of x)$.name=x.length===1?y:`${y} (${$.domain})`,(await b.save($)).success&&k++;k>0?(s.textContent=`Saved ${k} session(s)!`,s.className="modal-message success",document.dispatchEvent(new CustomEvent("seswi:session-updated")),setTimeout(T,800)):(s.textContent="Failed to save (duplicate name?)",s.className="modal-message error");return}if(o==="file"){if(!f.length){s.textContent="No sessions loaded — select a file first",s.className="modal-message error";return}const{data:y}=await b.getAll(),q=new Set(y.map(k=>k.timestamp)),x=f.filter(k=>!q.has(k.timestamp));for(const k of x)await b.save(k).catch(()=>{});s.textContent=`Imported ${x.length} of ${f.length} sessions`,s.className="modal-message success",document.dispatchEvent(new CustomEvent("seswi:sessions-restored")),setTimeout(T,900);return}const g=t.value.trim();if(!g){s.textContent="Please enter a name",s.style.display="block";return}const w={saveLocalStorage:document.getElementById("saveLocalStorage").checked,saveSessionStorage:document.getElementById("saveSessionStorage").checked},v=await D.handleAddSession(g,w);if(v.success){if(s.textContent="Saved!",s.className="modal-message success",document.getElementById("clearAfterSave")?.checked){T(),await O.cleanCurrentTab();return}setTimeout(T,800)}else s.textContent=v.error||"Failed to save",s.className="modal-message error"};document.getElementById("addSession").onclick=L,document.getElementById("addModalClose").onclick=T,document.getElementById("addModalCancel").onclick=T,document.getElementById("addModalSave").onclick=Z,e.onclick=g=>{g.target===e&&T()},t.onkeydown=g=>{g.key==="Enter"&&Z()},document.getElementById("importSessionName").onkeydown=g=>{g.key==="Enter"&&Z()},document.getElementById("clearInfoBtn")?.addEventListener("click",g=>{g.preventDefault(),document.getElementById("clearInfoText")?.classList.toggle("hidden")}),document.getElementById("statsInfoBtn")?.addEventListener("click",g=>{g.preventDefault(),document.getElementById("statsInfoText")?.classList.toggle("hidden")}),document.addEventListener("keydown",g=>{g.ctrlKey&&g.key==="n"&&(g.preventDefault(),L()),g.key==="Escape"&&e.style.display==="block"&&T()})}
